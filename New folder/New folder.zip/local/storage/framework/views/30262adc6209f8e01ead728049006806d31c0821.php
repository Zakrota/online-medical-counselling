 
<?php $__env->startSection('css'); ?>
<?php $__env->startSection("content"); ?>
  <section id="feature" class="transparent-bg">
        <div class="container">
           <div class="center wow fadeInDown">
                <h2>Our Services</h2>
                <p class="lead">Welcome to our services page, here you explore and try our provided services which <br> will help you getting better by asking our specialized doctors. </p>
            </div>

            <div class="row">
            <form action="/Chat/serviecs/">
                <div class="features">
                  
                    </div><!--/.col-md-4-->
                     <?php foreach($services as $c): ?>

                   <?php if(Auth::user()): ?>
                    <div class="col-md-4 col-sm-6 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
                        <div class="feature-wrap">
                            <i class="<?php echo e($c->Catogory_icon); ?>"></i>
                           <a href="<?php echo e($c->url); ?>/<?php echo e($c->id); ?>"> <h2><?php echo e($c->category_title); ?></h2></a>
                            <h3><?php echo $c->desc; ?></h3>
                        </div>
                    </div><!--/.col-md-4-->
                  <?php else: ?>
                  <div class="col-md-4 col-sm-6 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
                        <div class="feature-wrap">
                            <i class="<?php echo e($c->Catogory_icon); ?>"></i>
                           <a href="/section/servicess/<?php echo e($c->id); ?>"> <h2><?php echo e($c->category_title); ?></h2></a>
                            <h3><?php echo $c->desc; ?></h3>
                        </div>
                    </div><!--/.col-md-4-->
                    <?php endif; ?>
                      <?php endforeach; ?>               
                    </div><!--/.services-->
             </form>
            </div><!--/.row--> 

           </div>
               </section>
        <?php $__env->stopSection(); ?>
<?php $__env->startSection("scripts"); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>