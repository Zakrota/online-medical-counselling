<?php $__env->startSection('css'); ?>

<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/css/comment.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/css/post.css')); ?>" rel="stylesheet">
 <link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>

				<?php function formatDate($date){

				     return date('g:i a',strtotime($date));
				} ?>
               
               
        <div class="container">
                <div class="row">
                    <title><?php echo $title; ?> </title>

             </div>

          
  
	   <div class="row">
    
            <div class="col-xs-12 col-md-8-offset-1 ">
            	<div class="widget-area no-padding blank">
            		<div class="status-upload">
                      
            			<div class="post-heading">
                                <div class="pull-left image">
                                    <img src="<?php echo e(asset('images/user_1.jpg')); ?>" class="img-circle avatar" alt="user profile image">
                                </div>
	                     
                          
        					<form id="ajaxForm"   method="post">
        					  <?php echo csrf_field(); ?>

                                <input type="hidden" name="_method" value="POST" />
        						<textarea name="msg"  class="Confirm"  value="<?php echo e(old('msg')); ?>" placeholder="What are you doing right now?" ></textarea>
        						
        						<button type="submit" class="btn btn-success green Confirm" ><i class="fa fa-share"></i> Share</button>
        					</form>
                           
				         </div><!-- Status Upload  -->
                        
			         </div><!-- Widget Area -->
	        	</div>
	    	</div>
        </div>
         

         
     
        </div>
     
    <hr>
 <div class="container">
     <div class="row">
	   <div class="col-xs-12 col-md-8">
        <?php foreach($chat as $a  ): ?>
	     <div  id="chat" class="panel panel-white post panel-shadow">
	            
	             <div class="post-heading">
	                    <div class="pull-left image">
	                        <img src="<?php echo e(asset('images/user_1.jpg')); ?>" class="img-circle avatar" alt="user profile image">
	                    </div>

                         
	                    <div class="pull-left meta">
	                       
                            <div class="title h5">

                                <a id="name" href="#"><b><?php echo $a->name; ?></b></a>
                                
                            </div>
	                        <h6 id="time" class="text-muted time"><?php echo e(formatDate($a->date)); ?></h6>
	                    </div>
	                    
	              </div> 
	             <div class="post-description"> 
                    <p><?php echo $a->msg; ?></p>
                    <?php
                        $replay =  DB::table('replay-comment')->where('comment_id',$a->id)->get();
                    ?>

                    <?php foreach($replay as $ra): ?>

                     <div class="post-heading">
                        <div class="pull-left image">
                            <img src="<?php echo e(asset('images/user_1.jpg')); ?>" class="img-circle avatar" alt="user profile image">
                        </div>

                      <div class="pull-left meta">    
                           
                            <div class="title h4">

                                <a id="name1" href="#"><b><?php echo $ra->name; ?></b></a>
                                
                            </div>
                            <h6 id="time1" class="text-muted time"><?php echo e(formatDate($ra->date)); ?></h6>
                        </div>
                         </div>
                         <div class="post-description"> 
                           <p><?php echo $ra->msg; ?></p>
                         </div>

                      
               <?php endforeach; ?>
                
                <hr>
                 <form id="ajaxForm1"  class="Confirm"  method='post' class="post-footer">
                 
                      <?php echo csrf_field(); ?>

                                <input type="hidden" name="_method" value="POST" />
                   <div class="input-group"> 
                      
                    <input class="form-control"   name="replay" placeholder="Add a comment" type="text">
                    <span class="input-group-addon">
                        <button type="submit"><i class="fa fa-edit"></i></button>  
                    </span>
                   
                </div>
                </form>
              
                <hr>
           
              </div>
              </div>
             <?php endforeach; ?>

            
	       </div>

	      </div> </div> 
       

  

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>