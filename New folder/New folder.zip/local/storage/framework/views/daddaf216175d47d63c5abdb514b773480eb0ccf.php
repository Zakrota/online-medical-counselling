<?php $__env->startSection('css'); ?>

<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/css/comment.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/css/post.css')); ?>" rel="stylesheet">

<style>
.button {
    background-color: #DC143C; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin-left: 450px;
    cursor: pointer;
}

.button1 {border-radius: 2px;}
.button2 {border-radius: 4px;}
.button3 {border-radius: 8px;}
.button4 {border-radius: 12px;}
.button5 {border-radius: 50%;}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>

				<?php function formatDate($date){

				     return date('g:i a',strtotime($date));
				} ?>
                <link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css">
               
        <div class="container">
                <div class="row">
                    <title><?php echo $title; ?> </title>

             </div>
             
            
   
	   <div class="row">
    
            <div class="col-xs-12 col-md-8-offset-1 ">
            	<div class="widget-area no-padding blank">
            		<div class="status-upload">
                      
            			<div class="post-heading">
                                <div class="pull-left image">
                                    <img src="<?php echo e(asset('images/user_1.jpg')); ?>" class="img-circle avatar" alt="user profile image">
                                </div>
	                     
                          
        					<form id="ajaxForm"   action="/section/services/<?php echo e($services[0]->id); ?>" method="post">
        					  <?php echo csrf_field(); ?>

                                <input type="hidden" name="_method" value="POST" />
                                
            
        						<textarea name="msg"  class="<?php echo e(Auth::user()->user_id==0?'':'Confirmm'); ?>" value="<?php echo old('msg'); ?>" placeholder="What are you doing right now?" ></textarea>
        						
        						<button type="submit"  class=" btn btn-success green <?php echo e(Auth::user()->user_id==0?'':'Confirmm'); ?>" <i class="fa fa-share"></i> <i ></i> Share</button>
        					</form>
                           
				         </div><!-- Status Upload  -->
                        
			         </div><!-- Widget Area -->
	        	</div>
	    	</div>
        </div>
         

     
        </div>
     
    <hr>
 <div class="container">
     <div class="row">
	   <div class="col-xs-12 col-md-8">
        <?php foreach($chat as $a  ): ?>
	     <div  id="chat" class="panel panel-white post panel-shadow">
	            
	             <div class="post-heading">
	                    <div class="pull-left image">
                            
	                        <img src="<?php echo e(asset('images/user_1.jpg')); ?>" class="img-circle avatar" alt="user profile image">
	                    </div>
                      <?php if(Auth::user()->user_id==0): ?>
                    <div class="col-md-offset-11">
                    <form method="get" action="/section/delete/<?php echo e($a->id); ?>">
                     <input type="hidden" name="service_id" value="<?php echo e($a->service_id); ?>" />
                        <button  type="submit" class=" glyphicon glyphicon-minus-sign  "></button> 
                    </form>
                    
                    </div>
                         <?php endif; ?>  
                         
	                    <div class="pull-left meta">
	                       
                            <div class="title h5">

                                <a id="name" href="#"><b><?php echo $a->name; ?></b></a>
                                
                            </div>
	                        <h6 id="time" class="text-muted time"><?php echo e(formatDate($a->date)); ?></h6>
	                    </div>
	                    
	              </div> 
	             <div class="post-description"> 
                    <p><?php echo $a->msg; ?></p>
                    <?php
                        $replay =  DB::table('replay-comment')->where('comment_id',$a->id)->get();
                    ?>

                    <?php foreach($replay as $ra): ?>

                     <div class="post-heading">
                        <div class="pull-left image">
                            <img src="<?php echo e(asset('images/user_1.jpg')); ?>" class="img-circle avatar" alt="user profile image">
                        </div>
                      <?php if(Auth::user()->user_id==1): ?>
                    <div class="col-md-offset-11">
                    <form method="get" action="/section/delete1/<?php echo e($ra->id); ?>">
                     <input type="hidden" name="service_id" value="<?php echo e($ra->service_id); ?>" />
                        <button  type="submit" class=" glyphicon glyphicon-minus-sign  "></button> 
                    </form>
                    
                    </div>
                         <?php endif; ?>  
                      <div class="pull-left meta">    
                           
                            <div class="title h4">

                                <a id="name1" href="#"><b><?php echo $ra->name; ?></b></a>
                                
                            </div>
                            <h6 id="time1" class="text-muted time"><?php echo e(formatDate($ra->date)); ?></h6>
                        </div>
                         </div>
                         <div class="post-description"> 
                           <p><?php echo $ra->msg; ?></p>
                         </div>

                      
               <?php endforeach; ?>
                
                <hr>
                <?php if(Auth::user()->user_id==1): ?>
                 <form id="ajaxForm1" action="/section/replay/<?php echo e($a->id); ?>" method='post' class="post-footer">
                 <input type="hidden" name="service_id" value="<?php echo e($services[0]->id); ?>" />
                      <?php echo csrf_field(); ?>

                                <input type="hidden" name="_method" value="POST" />
                <div class="input-group"> 
                      
                    <input class="form-control" name="replay" placeholder="Add a comment" type="text">
                    <span class="input-group-addon">
                        <button type="submit"><i class="fa fa-edit"></i></button>  
                    </span>
                   
                </div>
                </form>
                 <?php endif; ?>
                <hr>
           
              </div>
              </div>
             <?php endforeach; ?>

            
	       </div>

	      </div> </div> 
       

  

<?php $__env->stopSection(); ?>
<?php $__env->startSection("scripts"); ?>

<script>
	

$(function(){

    $("#ajaxForm & #ajaxForm1").ajaxForm(function (x){


            $("#chat").append(" <div class='post-heading'>"+
                        "<div class='pull-left image'>"+
                             "<img src='<?php echo e(asset("images/user_1.jpg")); ?>' class='img-circle avatar' alt='user profile image'>"+
                         "</div>"+
                        " <div class='pull-left meta'>"+
                             "<div class='title h5'>"+
                                
                               "<a href='#'><b>+"("#ajaxForm #name").val()+"</b></a>"+ 
                                
                             "</div>"+
                             "<h6 class='text-muted time'>+"("#ajaxForm #time").val()+"</h6>"+
                         "</div>"+
                   "</div> "+
                  "<div class='post-description'> "+
                    " <p>"+$("#ajaxForm textarea").val()+"</p>"+
                     "<div class='pull-left meta'>"+    
                           
                            "<div class='title h5'>"+  

                                "<a href='#'><b>"+("#ajaxForm1 #name1").val()+"</b></a>"+  
                                
                            "</div>"+  
                            "<h6  class='text-muted time'>+"("#ajaxForm1 #time1").val()+"</h6>"+  
                        "</div>"+  

                         "<div class='post-description'> "+  
                           "<p>"+$("#ajaxForm1 textarea").val()+"</p>"+  
                         "</div>"+  

                        

                 "</div>"+
               "  <div class='post-footer'>"+
               "  <div class='input-group'> "+
                   "  <input class='form-control' placeholder='Add a comment' type='text'>"+
                    " <span class='input-group-addon'>"+
                     "    <a href='#'><i class='fa fa-edit'></i></a> "+ 
                   "  </span>"+
                " </div>"+
                 "<hr>"+

                " </div>");

            $("#ajaxForm textarea").val("");

    });

});


</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>