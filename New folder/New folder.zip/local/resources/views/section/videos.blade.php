  @extends('layout')

@section('content')
<style>
    .vid{
        padding-bottom: 30px;
        text-decoration: none;
        font-size: 29px;
    }
    .wll{
        padding-top: 33px;
        margin-left: 300px;
        font-size: 29px;
    }
    .dvdv{
        margin-top: -400px;
    }
</style>

<P class=vid>Welcome to the Vidoes Page, here you can find our educational tube</P>
<iframe class=vide width="900" height="400" src="https://www.youtube.com/embed/NOBp3RUZfBw" frameborder="3" allowfullscreen></iframe>
<br>
<p class="wll">- This video explains the DNA components and how people should evaluate<br> and check on themselves </p>
<div class="dvdv">
<table class="tbl">
    <ul class="unorder">
        <li><iframe width="190" height="160" src="https://www.youtube.com/embed/Ux38uobliGU" frameborder="0" allowfullscreen></iframe></li>
        <li><iframe width="190" height="160" src="https://www.youtube.com/embed/Ux38uobliGU" frameborder="0" allowfullscreen></iframe></li>
        <li><iframe width="190" height="160" src="https://www.youtube.com/embed/Ux38uobliGU" frameborder="0" allowfullscreen></iframe></li>
       
    
    
    </ul>



</table>
</div>
       
           
                <section id="portfolio">
        <div class="container">
            <div class="center">
               <h2>Educational brochures</h2>
               <p class="lead">Here we provide you with the Educational brochures that has been taken from the Ministry of Health (MOH) <br> these Educational brochures carries an important educational content.</p>
            </div>
        

           

            <div class="row">
                <div class="portfolio-items">
                    <div class="portfolio-item apps col-xs-12 col-sm-4 col-md-3">
                        <div class="recent-work-wrap">
                            <img class="img-responsive" src="{{asset('images/wan.jpg')}}" alt="">
                            <div class="overlay">
                                <div class="recent-work-inner">
                                    <h3><a href="#">Business theme</a></h3>
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                    <a class="preview" href="{{asset('images/wan.jpg')}}" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                </div> 
                            </div>
                        </div>
                    </div><!--/.portfolio-item-->

                    <div class="portfolio-item joomla bootstrap col-xs-12 col-sm-4 col-md-3">
                        <div class="recent-work-wrap">
                            <img class="img-responsive" src="{{asset('images/wan1.jpg')}}" alt="">
                            <div class="overlay">
                                <div class="recent-work-inner">
                                    <h3><a href="#">Business theme</a></h3>
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                    <a class="preview" href="{{asset('images/wan1.jpg')}}" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                </div> 
                            </div>
                        </div>          
                    </div><!--/.portfolio-item-->

                    <div class="portfolio-item bootstrap wordpress col-xs-12 col-sm-4 col-md-3">
                        <div class="recent-work-wrap">
                            <img class="img-responsive" src="{{asset('images/wan2.jpg')}}" alt="">
                            <div class="overlay">
                                <div class="recent-work-inner">
                                    <h3><a href="#">Business theme</a></h3>
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                    <a class="preview" href="{{asset('images/wan2.jpg')}}" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                </div> 
                            </div>
                        </div>        
                    </div><!--/.portfolio-item-->

                    <div class="portfolio-item joomla wordpress apps col-xs-12 col-sm-4 col-md-3">
                        <div class="recent-work-wrap">
                            <img class="img-responsive" src="{{asset('images/wan3.jpg')}}" alt="">
                            <div class="overlay">
                                <div class="recent-work-inner">
                                    <h3><a href="#">Business theme</a></h3>
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                    <a class="preview" href="{{asset('images/wan3.jpg')}}" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                </div> 
                            </div>
                        </div>           
                    </div><!--/.portfolio-item-->
          
                    <div class="portfolio-item joomla html bootstrap col-xs-12 col-sm-4 col-md-3">
                        <div class="recent-work-wrap">
                            <img class="img-responsive" src="{{asset('images/wan4.jpg')}}" alt="">
                            <div class="overlay">
                                <div class="recent-work-inner">
                                    <h3><a href="#">Business theme</a></h3>
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                    <a class="preview" href="{{asset('images/wan4.jpg')}}" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                </div> 
                            </div>
                        </div>      
                    </div><!--/.portfolio-item-->

                    <div class="portfolio-item wordpress html apps col-xs-12 col-sm-4 col-md-3">
                        <div class="recent-work-wrap">
                            <img class="img-responsive" src="{{asset('images/wan5.jpg')}}" alt="">
                            <div class="overlay">
                                <div class="recent-work-inner">
                                    <h3><a href="#">Business theme</a></h3>
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                    <a class="preview" href="{{asset('images/wan5.jpg')}}" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                </div> 
                            </div>
                        </div>         
                    </div><!--/.portfolio-item-->

                    <div class="portfolio-item wordpress html col-xs-12 col-sm-4 col-md-3">
                        <div class="recent-work-wrap">
                            <img class="img-responsive" src="{{asset('images/wan.jpg')}}" alt="">
                            <div class="overlay">
                                <div class="recent-work-inner">
                                    <h3><a href="#">Business theme</a></h3>
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                    <a class="preview" href="{{asset('images/wan.jpg')}}" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                </div> 
                            </div>
                        </div>          
                    </div><!--/.portfolio-item-->

                    <div class="portfolio-item wordpress html bootstrap col-xs-12 col-sm-4 col-md-3">
                        <div class="recent-work-wrap">
                            <img class="img-responsive" src="{{asset('images/wan.jpg')}}" alt="">
                            <div class="overlay">
                                <div class="recent-work-inner">
                                    <h3><a href="#">Business theme</a></h3>
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                    <a class="preview" href="{{asset('images/wan.jpg')}}" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                </div> 
                            </div>
                        </div>          
                    </div><!--/.portfolio-item-->
                </div>
            </div>
        </div>
    </section><!--/#portfolio-item-->
          
        

    @endsection